/*
 PARTNER INFORMATION
 Marina Sanusi // mgs9y@virginia.edu
 Sarah Bland // scb4ga@virginia.edu
*/

//
//  AddTimeViewController.swift
//  Stopwatch
//
//  Created by Sarah Bland on 2/9/18.
//  Copyright © 2018 UVa. All rights reserved.
//

import UIKit

class AddTimeViewController: UIViewController {

    var elapsedTime = ""
    @IBOutlet weak var simpleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        simpleLabel.text = elapsedTime
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func toSave(_ sender: Any) {
        let alertController = UIAlertController(title: "Time Saved!", message: "You just fake saved the time " + simpleLabel.text! + "!", preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(defaultAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func toCancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
}
